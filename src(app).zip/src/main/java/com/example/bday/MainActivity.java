package com.example.bday;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.transition.Slide;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    ViewPager viewPager;
    //add images from drawable to array
    int images[] = {R.drawable.img1, R.drawable.img2, R.drawable.img3, R.drawable.img4};
    SliderAdapter myCustomAdapter;
    int currentPageCunter = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = (ViewPager) findViewById(R.id.viewpager);
        myCustomAdapter = new SliderAdapter(MainActivity.this,images);
        viewPager.setAdapter(myCustomAdapter);
        final int[] currentPage = {0};
        final int NUM_PAGES = myCustomAdapter.getCount();
        //start of adding a music
        final MediaPlayer mediaPlayer = MediaPlayer.create(MainActivity.this,R.raw.ring);
        mediaPlayer.setLooping(true);
        mediaPlayer.setVolume(100,100);
        //end of music

        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage[0] == NUM_PAGES) {
                    currentPage[0] = 0;
                }
                mediaPlayer.start();
                viewPager.setCurrentItem(currentPage[0]++,true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 5000, 5000);
    }
}






